# VEF Falsification Criteria

## Purpose

This document explicitly states the conditions under which the Volume Exchange Field (VEF) framework would be **definitively falsified**. A scientific theory must be falsifiable to be considered science. VEF makes specific, testable predictions that differ from ΛCDM - if observations match ΛCDM and contradict VEF beyond measurement uncertainty, VEF is wrong.

---

## Immediate Falsification Tests (2026-2027)

### 1. DESI H(z) Measurements

**VEF Prediction:** H(z=1.5) = 161.4 ± 5.0 km/s/Mpc  
**ΛCDM Prediction:** H(z=1.5) = 158.9 ± 2.0 km/s/Mpc

**Falsification Condition:**
```
If DESI measures H(z=1.5) = 158.9 ± 2.0 km/s/Mpc with >3σ confidence
→ VEF is FALSIFIED
```

**Why this falsifies:** The pendulum model predicts specific θ(z) evolution. If H(z) follows ΛCDM exactly, the pendulum hypothesis is wrong.

**Timeline:** DESI DR3, Q4 2026

---

### 2. Euclid Weak Lensing Pattern

**VEF Prediction:** Lensing correlates with baryonic density / h_r (refractive gradient)  
**ΛCDM Prediction:** Lensing correlates with velocity dispersion (particle dark matter)

**Falsification Condition:**
```
If lensing shows:
- Strong correlation with gas velocity dispersion (σ_v > 500 km/s)
- NO correlation with baryonic density when corrected for radial scale
- Halo shapes match NFW/Einasto profiles
→ VEF is FALSIFIED
```

**Why this falsifies:** VEF predicts lensing from substrate compression (ordering pressure), not particle halos. If lensing follows particle dynamics, substrate model is wrong.

**Timeline:** Euclid DR1, Q2 2027

---

### 3. Rotation Curve Transition Radius

**VEF Prediction:** All galaxies transition to flat rotation at same a₀ ≈ 1.2 × 10⁻¹⁰ m/s²  
**ΛCDM Prediction:** Transition varies with halo concentration parameter

**Falsification Condition:**
```
If 1000+ galaxy sample shows:
- r_transition scatter > 50% (not universal)
- r_transition correlates with environment (as expected for halos)
- NO correlation with a₀ threshold
→ VEF is FALSIFIED
```

**Why this falsifies:** Universal a₀ is central to VEF. If rotation curves show halo-like diversity, ordering pressure model is wrong.

**Timeline:** SKA HI Survey, 2028-2029

---

## Medium-Term Falsification (2027-2030)

### 4. High-z Galaxy Formation Timeline

**VEF Prediction:** Galaxies at z > 10 appear systematically "too mature" due to scale-dependent h_r  
**ΛCDM Prediction:** Galaxy properties match age from Big Bang chronology

**Falsification Condition:**
```
If JWST Cycle 3-5 finds:
- 100+ galaxies at z > 10 with ages matching ΛCDM exactly
- NO systematic offset toward higher maturity
- Stellar populations consistent with standard formation
→ VEF is FALSIFIED (at least the h_r scaling component)
```

**Why this falsifies:** VEF predicts scale-dependent apparent ages. If ΛCDM timeline is exact, the radial Planck gradient hypothesis is wrong.

**Timeline:** JWST Cycles 3-5, 2026-2029

---

### 5. Dark Matter Direct Detection

**VEF Prediction:** "Dark matter" is ordering pressure, not particles  
**ΛCDM Prediction:** WIMPs/Axions exist as particles

**Falsification Condition:**
```
If experiments detect:
- Dark matter particles with mass, cross-section, velocity distribution
- Consistent signal across multiple detectors
- Properties incompatible with substrate compression explanation
→ VEF is FALSIFIED
```

**Why this falsifies:** VEF explains dark matter effects without particles. If particles are directly detected, VEF's substrate explanation is wrong.

**Timeline:** XENONnT/LZ/DARWIN, ongoing

---

## Long-Term Falsification (2030+)

### 6. Gravitational Wave Dispersion

**VEF Prediction:** GW show frequency-dependent speed: c_GW(f) = c₀(1 - α·f²), α ~ 10⁻²⁰ Hz⁻²  
**GR Prediction:** Perfect dispersionless propagation

**Falsification Condition:**
```
If LISA measures:
- Zero dispersion to precision Δc/c < 10⁻²² 
- Across 100+ binary mergers
- In frequency range 10⁻⁴ to 1 Hz
→ VEF is FALSIFIED (substrate elasticity prediction wrong)
```

**Why this falsifies:** VEF treats GW as substrate waves, GR treats them as spacetime ripples. Zero dispersion confirms GR's purely geometric picture.

**Timeline:** LISA mission, 2037+

---

### 7. Lorentz Invariance at E > 10¹⁹ GeV

**VEF Prediction:** Lorentz invariance breaks at Planck energy due to substrate "grain"  
**SR Prediction:** Perfect Lorentz invariance at all energies

**Falsification Condition:**
```
If UHECR experiments with 10,000+ events show:
- Perfect isotropy at E > 10²⁰ eV
- NO directional anisotropy
- Time-of-flight consistent with exact Lorentz invariance
→ VEF is FALSIFIED (substrate discreteness prediction wrong)
```

**Why this falsifies:** VEF predicts substrate has "grain" at Planck scale. If Lorentz symmetry is exact, space is truly smooth/continuous.

**Timeline:** Auger/IceCube statistics, ~2032

---

### 8. Cosmological Constant Variation

**VEF Prediction:** "Dark energy" varies with θ(t), not truly constant  
**ΛCDM Prediction:** Λ is constant across cosmic time

**Falsification Condition:**
```
If precision measurements find:
- ρ_Λ constant to Δρ/ρ < 10⁻⁴ from z=2 to z=0
- NO correlation with cosmic evolution
- Perfect agreement with constant w = -1
→ VEF is FALSIFIED (pendulum momentum prediction wrong)
```

**Why this falsifies:** VEF explains accelerating expansion as θ approaching 0.5. If Λ is exactly constant, pendulum model is wrong.

**Timeline:** Roman + Euclid joint analysis, 2030+

---

## Partial Falsification Scenarios

### Scenario A: Cosmology Wrong, Local Physics Right
**Observations:**
- DESI H(z) matches ΛCDM exactly
- BUT rotation curves still show universal a₀
- AND Pioneer anomaly still ~8.7 × 10⁻¹⁰ m/s²

**Interpretation:** 
- Pendulum/θ(z) model is wrong
- But ordering pressure may still apply locally
- VEF needs major revision, not complete abandonment

---

### Scenario B: Local Physics Wrong, Cosmology Right  
**Observations:**
- DESI H(z) matches VEF predictions
- BUT dark matter particles are detected
- OR rotation curves show halo-like diversity

**Interpretation:**
- Hubble tension explanation may be correct
- But substrate/ordering pressure is wrong
- Need hybrid model: cosmic evolution + particle DM

---

### Scenario C: Everything Wrong
**Observations:**
- All predictions fail at >3σ
- ΛCDM matches every observation perfectly
- No anomalies remain unexplained

**Interpretation:**
- VEF is completely falsified
- Back to standard cosmology
- Dark matter particles exist, Λ is real
- Checkerboard equilibrium is not the substrate principle

---

## What Would Support VEF?

For completeness, here are observations that would strongly support VEF:

### Strong Support
1. DESI H(z=1.5) = 161.4 ± 3 km/s/Mpc (**>3σ from ΛCDM**)
2. Euclid lensing shows refractive pattern, not particle halos
3. SKA measures universal a₀ with <10% scatter
4. JWST finds systematic high-z maturity offset

### Moderate Support  
5. Roman voids scale with ordering pressure
6. LISA detects GW dispersion
7. No dark matter particles detected despite sensitivity
8. CMB distortions match VEF prediction

### Weak Support (Still Consistent)
9. Mixed results that don't clearly favor either model
10. Some anomalies explained, others not
11. Need for hybrid model

---

## Scientific Integrity Statement

**This document is pre-registered** (timestamped February 10, 2026) to prevent post-hoc rationalization.

**Commitment:**
- If DESI measures H(z=1.5) = 158.9 ± 2 km/s/Mpc, I will publicly acknowledge VEF is falsified
- No moving goalposts or adding parameters to "save" the theory
- No claiming "systematic errors" without independent evidence
- If wrong, VEF is wrong - period

**The beauty of science:** Theories that make risky predictions and fail are valuable. They eliminate wrong paths and guide future research.

---

## Confidence Intervals

My personal confidence levels (as of Feb 2026):

| Prediction | Confidence VEF Correct |
|------------|----------------------|
| DESI H(z) matches VEF | 60% |
| Euclid shows refractive pattern | 70% |
| SKA measures universal a₀ | 75% |
| JWST confirms maturity offset | 65% |
| Dark matter particles NOT found | 80% |
| LISA detects dispersion | 40% |
| Lorentz violation at 10¹⁹ GeV | 50% |

**Overall VEF validity: 55%** (better than coin flip, but not overwhelming confidence)

**This uncertainty is appropriate for a new theoretical framework.**

---

## Conclusion

VEF is **falsifiable**. It makes specific, testable predictions that differ quantitatively from ΛCDM. The critical test occurs in Q4 2026 with DESI DR3.

If VEF is wrong, we'll know soon.  
If VEF is right, we'll know soon.

Either way, we learn.

**That's how science should work.**

---

**Document Version:** 1.0  
**Last Updated:** February 10, 2026  
**Status:** Pre-registered predictions  
**Next Update:** After DESI DR3 (December 2026)
